package modelo;

import modelo.dao.ComprasDAO;
import modelo.dao.ProductoDAO;
import modelo.dto.ClienteDTO;
import modelo.dto.ComprasDTO;
import modelo.dto.ProductoDTO;

// Contiene las reglas de negocio de la tienda DON APARATO
// Calcula descuentos según el tipo de afiliación del cliente
public class LogicaDeVenta {

    private final ComprasDAO  comprasDAO  = new ComprasDAO();
    private final ProductoDAO productoDAO = new ProductoDAO();

    /**
     * Procesa una venta aplicando el descuento según el tipo del cliente:
     *   Tipo A → 40% de descuento
     *   Tipo B → 20% de descuento
     *   Tipo C → 10% de descuento
     *   Sin tipo → sin descuento
     *
     * @param cliente  ClienteDTO con el tipo de afiliación
     * @param producto ProductoDTO seleccionado
     * @param cantidad cuántas unidades compra
     * @return ComprasDTO con todos los valores calculados, o null si hay error
     */
    public ComprasDTO procesarVenta(ClienteDTO cliente, ProductoDTO producto, int cantidad) {

        // Validación: cantidad mayor a 0
        if (cantidad <= 0) return null;

        // Validación: stock suficiente
        if (cantidad > producto.getStock()) return null;

        double valorUnitario = producto.getPrecio();
        double totalSinDesc  = valorUnitario * cantidad;

        // Calcula el descuento según el tipo del cliente
        double porcentaje = cliente.getPorcentajeDescuento();
        double descuento  = totalSinDesc * porcentaje;
        double totalFinal = totalSinDesc - descuento;

        // Crea el DTO con todos los valores calculados
        ComprasDTO compra = new ComprasDTO(
            cliente.getId(), producto.getId(), cantidad,
            valorUnitario, totalSinDesc, descuento, totalFinal
        );

        // Guarda la compra en BD
        boolean guardada = comprasDAO.insertar(compra);
        if (!guardada) return null;

        // Descuenta el stock del producto
        productoDAO.reducirStock(producto.getId(), cantidad);

        return compra; // Retorna el DTO con todos los valores para mostrar en pantalla
    }

    // Versión con solo idCliente (compatibilidad con el flujo anterior)
    // Retorna mensaje de texto para VentanaCompras del admin
    public String procesarVenta(ProductoDTO producto, int idCliente, int cantidad) {
        if (cantidad <= 0)              return "La cantidad debe ser mayor a 0.";
        if (cantidad > producto.getStock())
            return "Stock insuficiente. Solo hay " + producto.getStock() + " unidades.";

        double total = producto.getPrecio() * cantidad;
        ComprasDTO dto = new ComprasDTO(idCliente, producto.getId(), cantidad,
                producto.getPrecio(), total, 0, total);

        boolean ok = comprasDAO.insertar(dto);
        if (!ok) return "Error al registrar la compra en la base de datos.";
        productoDAO.reducirStock(producto.getId(), cantidad);
        return "Compra realizada. Total: $" + String.format("%,.0f", total);
    }
}