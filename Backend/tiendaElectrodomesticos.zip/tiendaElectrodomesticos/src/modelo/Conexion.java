package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * ============================================================
 *  CLASE: Conexion
 *  PAQUETE: modelo
 * ============================================================
 *  PROPÓSITO:
 *    Centraliza la conexión JDBC con MySQL.
 *    Todos los DAO la usan para obtener una conexión activa.
 *
 *  FLUJO:
 *    DAO → Conexion.getConexion() → devuelve objeto Connection
 *                                 → DAO ejecuta su SQL
 * ============================================================
 */
public class Conexion {

    // ── Datos de conexión ─────────────────────────────────
    private static final String URL      = "jdbc:mysql://localhost:3306/tienda_db?useSSL=false&serverTimezone=UTC";
    private static final String USUARIO  = "root";
    private static final String PASSWORD = "Janner12345@";  // ← cambia esto

    /**
     * Retorna una conexión activa a la base de datos.
     * Se llama cada vez que un DAO necesita ejecutar una consulta.
     */
    public static Connection getConexion() throws SQLException {
        try {
            // Carga el driver de MySQL en memoria
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver MySQL no encontrado. Agrega el JAR al Build Path.");
        }
        // Crea y devuelve la conexión
        return DriverManager.getConnection(URL, USUARIO, PASSWORD);
    }
}