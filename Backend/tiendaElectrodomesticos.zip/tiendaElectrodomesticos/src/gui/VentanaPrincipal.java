package gui;

// Esta ventana ya no se usa en la version actual
// Se mantiene solo para evitar errores de compilacion
public class VentanaPrincipal extends javax.swing.JFrame {
    public VentanaPrincipal() {}
    public void cargarDatos() {}
    public void cargarInventario() {}
    public void cargarHistorialCompras() {}
}